"""Local replay and descriptive accounting; no model requests or semantic census."""
import collections,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import run

def main():
 rows=[];errors=[];groups={}
 for f in sorted((HERE/'live').glob('*.json')):
  r=json.loads(f.read_text())
  if 'case' not in r:continue
  e=run.ENVIRONMENTS[r['case']['environment']](r['case']['seed'],r['case']['condition'])
  try:
   assert e.result()==r['initial_result']
   for t in r['turns']:
    assert e.observe(t['agent'])==t['observation']
    e.step(t['agent'],t['parsed']['action']);assert e.result()==t['state_after']
   assert e.result()==r['result']
   assert len(r['turns'])==len(e.turns) if r['complete'] else True
  except Exception as exc:errors.append({'id':r['id'],'error':repr(exc)})
  rows.append(r)
  key=r['case']['environment'];g=groups.setdefault(key,{'episodes':0,'complete':0,'turns':0,'actions':collections.Counter(),'queries':collections.Counter(),'correct_decisions':0,'decision_episodes':0,'conditions':collections.Counter(),'failed_game_actions':[],'task_outcomes':[]})
  g['episodes']+=1;g['complete']+=r['complete'];g['turns']+=len(r['turns']);g['conditions'][r['case']['condition']]+=1
  for t in r['turns']:
   a=t.get('parsed',{}).get('action',{});g['actions'][a.get('type',a.get('op','invalid'))]+=1
   if a.get('type')=='query':g['queries'][a['key']]+=1
  g['failed_game_actions'].extend({'id':r['id'],'event':v} for v in r['result'].get('events',[]) if v.get('success') is False)
  g['task_outcomes'].append({'id':r['id'],'condition':r['case']['condition'],'model':r['case']['model'],'state':r['result']['state'],'scores':r['result']['scores']})
  if key in ['investigation','relay_incident'] and r['complete']:
   g['decision_episodes']+=1
   g['correct_decisions']+=r['result']['state']['decision']==e.correct_choice
 progress=json.loads((HERE/'progress.json').read_text())
 out={'collection_status':progress['status'],'episodes':len(rows),'complete':sum(r['complete'] for r in rows),'replay_errors':errors,'groups':groups,'new_accounted_upper_usd':progress['cost']['accounted_upper_usd'],'cumulative_accounted_upper_usd':1.13890725+progress['cost']['accounted_upper_usd'],'source_hashes':{r['id']:run.digest(HERE/'live'/(r['id']+'.json')) for r in rows},'semantic_scope':'Descriptive state/action census only; semantic category absence and intent are not inferred.'}
 run.write(HERE/'local_analysis.json',out)
 print(json.dumps({k:v for k,v in out.items() if k!='source_hashes'},indent=2))
if __name__=='__main__':main()
