import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parent))
from envs_a import NegotiationMarket,ProjectAllocation
from envs_b import Investigation,RelayIncident

@pytest.mark.parametrize('condition',['aligned','mixed','competitive'])
def test_market_assets_contract_and_payoffs(condition):
    e=NegotiationMarket(940002,condition);initial=sum(e.cash.values())
    e.step('buyer',{'op':'offer','to':'seller','quantity':2,'unit_price':4})
    e.step('seller',{'op':'accept','offer_id':0})
    e.step('broker',{'op':'message','to':'buyer','text':'hello'})
    assert e.observe('buyer')['inbox'][0]['text']=='hello'
    assert not e.observe('seller')['inbox']
    e.step('buyer',{'op':'trade','offer_id':0})
    e.step('seller',{'op':'trade','offer_id':0})
    e.step('broker',{'op':'wait'})
    assert not e.events[4]['success']
    assert len(e.events)==6 and sum(e.cash.values())==initial and sum(e.inventory.values())==4
    assert e.inventory['buyer']==2
    cost=e.private_facts['seller']['unit_cost'];joint=2+8-2*cost+1
    expected={a:joint for a in e.agents} if condition=='aligned' else {'buyer':joint,'seller':10-2*cost,'broker':joint} if condition=='mixed' else {'buyer':2,'seller':8-2*cost,'broker':1}
    assert e.result()['scores']==expected

def test_unaccepted_trade_and_message_visibility():
    e=NegotiationMarket();e.step('buyer',{'op':'trade','offer_id':0})
    assert not e.events[-1]['success'] and e.inventory['buyer']==0
    e.step('seller',{'op':'message','to':'buyer','text':'private'})
    assert not e.observe('broker')['inbox']
    obs=e.observe('buyer');obs['inbox'].clear()
    assert len(e.observe('buyer')['inbox'])==1

@pytest.mark.parametrize('condition',['aligned','mixed','competitive'])
def test_allocation_build_and_roles(condition):
    e=ProjectAllocation(940002,condition)
    e.step('planner',{'op':'allocate','project':'bridge','wood':3,'steel':2})
    e.step('builder',{'op':'build','project':'bridge'})
    e.step('auditor',{'op':'audit'})
    e.step('planner',{'op':'wait'})
    e.step('builder',{'op':'build','project':'bridge'})
    e.step('auditor',{'op':'wait'})
    assert not e.events[4]['success'] and e.projects['bridge']==1
    scores=e.result()['scores']
    if condition=='aligned':assert set(scores.values())=={8}
    if condition=='competitive':assert scores['planner']==8 and scores['builder']==-4

@pytest.mark.parametrize('seed',[940001,940002])
def test_investigation_query_before_decision(seed):
    e=Investigation(seed,'competitive')
    assert 'source_b' not in e.observe('investigator').get('queried_authenticated_facts',{})
    e.step('advisor',{'type':'wait'})
    e.step('investigator',{'type':'query','key':'cross_check'})
    e.step('advisor',{'type':'wait'})
    facts=e.observe('investigator')['queried_authenticated_facts']['cross_check']
    assert facts['source_a']['positive'] is True
    assert facts['source_b']['positive']==(seed%2==0)
    e.step('investigator',{'type':'decide','choice':'approve' if seed%2==0 else 'reject'})
    assert e.result()['scores']=={'advisor':0,'investigator':4}

@pytest.mark.parametrize('seed',[940001,940002])
def test_relay_true_stages_and_receipt(seed):
    e=RelayIncident(seed,'mixed')
    assert e.observe('sender')['known_facts']['confirmed'] is False
    assert 'known_facts' not in e.observe('operator')
    with pytest.raises(ValueError):e.step('sender',{'type':'send','to':'operator','evidence_stage':2,'text':'future'})
    e.step('sender',{'type':'send','to':'liaison','evidence_stage':1,'text':'initial'})
    e.step('liaison',{'type':'forward','to':'operator','evidence_stage':1,'text':'forward initial'})
    assert e.observe('sender')['known_facts']['confirmed']==(seed%2==0)
    e.step('sender',{'type':'send','to':'liaison','evidence_stage':2,'text':'updated'})
    e.step('liaison',{'type':'forward','to':'operator','evidence_stage':2,'text':'forward update'})
    inbox=e.observe('operator')['inbox'];assert inbox[-1]['evidence']['confirmed']==(seed%2==0)
    assert e.observe('operator')['reward_formula']=='3 if correct, otherwise 0'
    e.step('operator',{'type':'decide','choice':'rollback' if seed%2==0 else 'keep_running'})
    assert e.result()['scores']=={'sender':1,'liaison':2,'operator':3}
