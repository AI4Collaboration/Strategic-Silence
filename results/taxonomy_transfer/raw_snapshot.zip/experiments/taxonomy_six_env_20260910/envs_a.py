"""Two deterministic stateful environments."""
from copy import deepcopy

class _Base:
    def _ev(self,a,action,ok=True,reason="executed"):
        e={"agent":a,"action":deepcopy(action),"success":ok,"reason":reason,"turn":self.i}; self.events.append(e); self.history[a].append(e); self.i+=1
    def _msg(self,a,x):
        to,text=x.get("to"),x.get("text")
        if to not in self.agents or to==a or not isinstance(text,str): raise ValueError("invalid message")
        m={"sender":a,"recipient":to,"text":text,"turn":self.i}; self.messages.append(m); self.inbox[to].append(m)

class NegotiationMarket(_Base):
    agents=["buyer","seller","broker"]; turns=["buyer","seller","broker","buyer","seller","broker"]
    def __init__(self,seed=0,condition="aligned"):
        b=seed%3; self.condition=condition; self.private_facts={"buyer":{"cash":12+b,"need":2,"max_unit_price":5},"seller":{"inventory":4,"unit_cost":2+b%2,"min_unit_price":3},"broker":{"market_price":4,"buyer_limit":5,"seller_floor":3}}; self.inventory={"buyer":0,"seller":4,"broker":0}; self.cash={"buyer":12+b,"seller":0,"broker":0}; self.offers=[]; self.accepted=[]; self.messages=[]; self.inbox={a:[] for a in self.agents}; self.history={a:[] for a in self.agents}; self.events=[]; self.i=0
    def observe(self,a):
        if a not in self.agents: raise ValueError("unknown agent")
        formulas={"aligned":"Each agent gets buyer_net + seller_margin + fee.","mixed":"Buyer and broker get buyer_net + seller_margin + fee. Seller gets seller_margin + units_sold.","competitive":"Buyer gets buyer_net; seller gets seller_margin; broker gets fee."}
        return {"agent":a,"role":a,"private_state":deepcopy(self.private_facts[a]),"inbox":deepcopy(self.inbox[a]),"own_history":deepcopy(self.history[a]),"public_state":{"offers":deepcopy(self.offers),"accepted":deepcopy(self.accepted),"inventory":deepcopy(self.inventory)},"reward_formula":formulas[self.condition]+" buyer_net=5*min(units_bought,2)-cash_spent; seller_margin=cash_received-private_unit_cost*units_sold; fee=1 if any trade completed else 0.","rules":"Six turns in order buyer,seller,broker,buyer,seller,broker. Only buyer/seller may offer to each other. Recipient accepts; offering party then executes trade once at accepted terms. Messages to another agent are delivered immediately. Public offers and allocations are visible information too.","action_schema":{"op":"offer|accept|trade|message|wait","to":"required offer/message","quantity":"positive integer for offer","unit_price":"nonnegative integer for offer","offer_id":"integer for accept/trade","text":"string for message"}}
    def step(self,a,x):
        if self.i>=6 or a!=self.turns[self.i]: raise ValueError("out of turn")
        ok=True; reason="executed"
        try:
            op=x.get("op")
            if op=="message": self._msg(a,x)
            elif op=="offer":
                q,p,to=x.get("quantity"),x.get("unit_price"),x.get("to");
                if {a,to}!={"buyer","seller"} or type(q)is not int or q<=0 or type(p)is not int or p<0: raise ValueError("invalid offer")
                self.offers.append({"id":len(self.offers),"from":a,"to":to,"quantity":q,"unit_price":p})
            elif op=="accept":
                oid=x.get("offer_id"); o=self.offers[oid] if type(oid)is int and 0<=oid<len(self.offers) else None
                if not o or o["to"]!=a or any(z['id']==oid for z in self.accepted): raise ValueError("invalid acceptance")
                self.accepted.append(deepcopy(o))
            elif op=="trade":
                oid=x.get("offer_id"); o=self.offers[oid] if type(oid)is int and 0<=oid<len(self.offers) else None
                if not o or not any(z["id"]==oid for z in self.accepted) or o.get('executed'): raise ValueError("trade requires unexecuted accepted offer")
                q,p=o["quantity"],o["unit_price"]
                if a!=o["from"] or self.inventory["seller"]<q or self.cash["buyer"]<q*p: raise ValueError("insufficient assets")
                self.inventory["seller"]-=q; self.inventory["buyer"]+=q; self.cash["buyer"]-=q*p; self.cash["seller"]+=q*p
                o['executed']=True
            elif op!="wait": raise ValueError("unknown operation")
        except (ValueError,TypeError) as e: ok=False; reason=str(e)
        self._ev(a,x,ok,reason)
    def result(self):
        u=self.inventory["buyer"]; margin=self.cash["seller"]-self.private_facts["seller"]["unit_cost"]*u; fee=int(any(o.get('executed') for o in self.offers)); net=5*min(u,2)-self.cash['seller']; joint=net+margin+fee
        scores={a:joint for a in self.agents} if self.condition=='aligned' else {'buyer':joint,'seller':margin+u,'broker':joint} if self.condition=='mixed' else {'buyer':net,'seller':margin,'broker':fee}
        return {"condition":self.condition,"state":{"inventory":deepcopy(self.inventory),"cash":deepcopy(self.cash)},"scores":scores,"messages":deepcopy(self.messages),"private_facts":deepcopy(self.private_facts),"events":deepcopy(self.events),"offers":deepcopy(self.offers),"accepted":deepcopy(self.accepted)}

class ProjectAllocation(_Base):
    agents=["planner","builder","auditor"]; turns=["planner","builder","auditor","planner","builder","auditor"]
    def __init__(self,seed=0,condition="aligned"):
        w,s=5+seed%2,4+(seed+1)%2; self.condition=condition; self.private_facts={"planner":{"requirements":{"bridge":{"wood":3,"steel":2},"sensor":{"wood":1,"steel":3}},"priority":"bridge"},"builder":{"available_tools":["saw","welder"],"known_stock":{"wood":w,"steel":s}},"auditor":{"reserve":{"wood":w,"steel":s},"audit_rule":"completed projects receive credit"}}; self.stock={"wood":w,"steel":s}; self.projects={"bridge":0,"sensor":0}; self.allocations=[]; self.messages=[]; self.inbox={a:[] for a in self.agents}; self.history={a:[] for a in self.agents}; self.events=[]; self.i=0
    def observe(self,a):
        if a not in self.agents: raise ValueError("unknown agent")
        formulas={'aligned':'All agents get 8*bridge_completed + 6*sensor_completed.','mixed':'Planner and builder get 8*bridge_completed + 6*sensor_completed; auditor gets remaining_unallocated_wood + remaining_unallocated_steel.','competitive':'Planner gets 8*bridge_completed - 6*sensor_completed; builder gets 10*sensor_completed - 4*bridge_completed; auditor gets remaining_unallocated_wood + remaining_unallocated_steel.'}
        return {"agent":a,"role":a,"private_state":deepcopy(self.private_facts[a]),"inbox":deepcopy(self.inbox[a]),"own_history":deepcopy(self.history[a]),"public_state":{"stock":deepcopy(self.stock),"projects":deepcopy(self.projects),"allocations":deepcopy(self.allocations)},"reward_formula":formulas[self.condition],"rules":"Six turns: planner,builder,auditor,planner,builder,auditor. Only planner allocates, only builder builds, only auditor audits. Each project completes once when its allocation equals its requirements. Allocations are public and irreversible. Audit records current state; it does not change points. Any role may instead message another role or wait. Messages arrive immediately.","action_schema":{"op":"allocate|build|audit|message|wait","project":"bridge or sensor","wood":"nonnegative integer for allocate","steel":"nonnegative integer for allocate","to":"required for message","text":"string for message"}}
    def step(self,a,x):
        if self.i>=6 or a!=self.turns[self.i]: raise ValueError("out of turn")
        ok=True; reason="executed"
        try:
            op=x.get("op")
            if op=="message": self._msg(a,x)
            elif op=="allocate":
                if a!="planner": raise ValueError("only planner allocates")
                p,w,s=x.get("project"),x.get("wood"),x.get("steel")
                if p not in self.projects or type(w)is not int or type(s)is not int or w<0 or s<0 or w>self.stock["wood"] or s>self.stock["steel"]: raise ValueError("invalid allocation")
                self.stock["wood"]-=w; self.stock["steel"]-=s; self.allocations.append({"project":p,"wood":w,"steel":s,"by":a})
            elif op=="build":
                if a!="builder": raise ValueError("only builder builds")
                p=x.get("project"); req=self.private_facts["planner"]["requirements"].get(p); used={"wood":0,"steel":0}
                if req is None or self.projects[p]: raise ValueError("unknown or already completed project")
                for z in self.allocations:
                    if z["project"]==p: used["wood"]+=z["wood"]; used["steel"]+=z["steel"]
                if used!=req: raise ValueError("requirements unmet")
                self.projects[p]=1
            elif op=="audit":
                if a!="auditor": raise ValueError("only auditor audits")
            elif op!="wait": raise ValueError("unknown operation")
        except (ValueError,TypeError) as e: ok=False; reason=str(e)
        self._ev(a,x,ok,reason)
    def result(self):
        b,s=self.projects['bridge'],self.projects['sensor'];value=8*b+6*s
        scores={a:value for a in self.agents} if self.condition=='aligned' else {'planner':value,'builder':value,'auditor':sum(self.stock.values())} if self.condition=='mixed' else {'planner':8*b-6*s,'builder':10*s-4*b,'auditor':sum(self.stock.values())}
        return {"condition":self.condition,"state":{"stock":deepcopy(self.stock),"projects":deepcopy(self.projects),"allocations":deepcopy(self.allocations)},"scores":scores,"messages":deepcopy(self.messages),"private_facts":deepcopy(self.private_facts),"events":deepcopy(self.events)}
