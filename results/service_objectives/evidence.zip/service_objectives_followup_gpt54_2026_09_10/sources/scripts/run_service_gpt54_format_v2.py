"""Frozen fresh-case follow-up; same interface, GPT-5.4 profile, and scoring."""
import argparse
from collections import Counter
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts import run_service_gpt54_pairs as pilot
from scripts import service_communication_v2 as repaired


def prepare(parent,out):
    cfg=deepcopy(json.loads((parent/'config.json').read_text()))
    parent_rows=list(map(json.loads,(parent/'episodes.jsonl').read_text().splitlines()))
    assert len(parent_rows)==len(cfg['design'])
    for path,h in cfg['source_hashes'].items():assert hashlib.sha256((parent/'sources'/path).read_bytes()).hexdigest()==h
    journal=parent/'provider_journal.jsonl';amounts={}
    for e in map(json.loads,journal.read_text().splitlines()):
        if e['kind']=='reserve':amounts[e['id']]=e['reservation_nano']
        elif e['kind']=='response':amounts[e['id']]=e['accounted_nano']
    prior=cfg['prior_accounted_nano']+sum(amounts.values())
    assert prior==pilot.old.nano(json.loads((parent/'summary.json').read_text())['accounting']['cumulative_accounted_upper_usd'])
    design=[dict(model=pilot.MODEL,case=asdict(pilot.old.base.Case(('factory','pipeline')[i%2],609400+i,'split')),
                 arm=arm,mode='original_plan',pair=i)
            for i in range(4) for arm in (('per_call','transfer_credit') if i%2==0 else ('transfer_credit','per_call'))]
    assert {r['case']['seed'] for r in design}.isdisjoint(r['case']['seed'] for r in parent_rows)
    cfg.update(protocol='service_gpt54_format_v2',design=design,
        prior_accounted_nano=prior,incremental_cap_nano=cfg['authorized_cap_nano']-prior,
        prior_sources=cfg['prior_sources']+[dict(path=str(journal.resolve()),sha256=hashlib.sha256(journal.read_bytes()).hexdigest())],
        discovery_parent=str(parent.resolve()),
        format_gate='Already passed in preceding pilot; run fixed follow-up list regardless of behavioral outcomes. Preserve invalid pairs; no replacements.',
        primary='Per-call minus transfer-credit gap fraction for each complete case pair, after source-hashed semantic review. Report valid pairs, mean paired difference, ties/reversals, and all invalid/unrun cases. Follow-up hypothesis: higher gap fraction under per-call. Do not pool discovery and follow-up for the primary result.')
    cfg['source_hashes']={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in cfg['source_hashes']}
    cfg['source_hashes']['scripts/service_communication_v2.py']=hashlib.sha256((ROOT/'scripts/service_communication_v2.py').read_bytes()).hexdigest()
    cfg['source_hashes'][str(Path(__file__).relative_to(ROOT))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out.mkdir(parents=True,exist_ok=False)
    for path,h in cfg['source_hashes'].items():
        target=out/'sources'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/path).read_bytes())
    pilot.old.write(out/'config.json',cfg)
    (out/'PROTOCOL.md').write_text("""# GPT-5.4 format-v2 service replication

Four fresh matched cases, seeds 609400-609403; eight episodes. Per-call and transfer-credit contracts, counterbalanced order. Both roles remain GPT-5.4/OpenAI with the inherited low-reasoning profile. Communication v2 adds exact routing examples and normalizes only unambiguous missing recipient punctuation; original raw responses and normalization metadata are retained. No ambiguous recipient repair or output retry. All other service mechanics and client branches are unchanged.

Primary unit is the case pair: compare per-call minus transfer-credit useful-information gap after semantic review. Report all completed, invalid and unrun episodes, all ties and reversals. This is a separate versioned cohort; no pooling with v1. Run the fixed eight episodes irrespective of behavioral outcomes, stopping only for budget/provider failure. No replacements. Original $5 cumulative cap includes all predecessor reservations. No paid judges or cross-model changes. Service and crafting/trading remain two distinct environments; this batch tests service only.
""")
    return cfg


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--parent',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--live',action='store_true');a=p.parse_args()
    cfg=json.loads((a.output/'config.json').read_text()) if (a.output/'config.json').exists() else prepare(a.parent,a.output)
    for path,h in cfg['source_hashes'].items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h
    if not a.live:print(json.dumps(dict(planned=len(cfg['design']),remaining_usd=cfg['incremental_cap_nano']/1e9)));return
    budget=pilot.old.Budget(a.output,cfg,pilot.old.live_transport());dest=a.output/'episodes.jsonl'
    rows=list(map(json.loads,dest.read_text().splitlines())) if dest.exists() else []
    def call(key,model,messages,tools=None):
        options=dict(model=model,messages=messages,**cfg['models'][model]['generation'])
        if tools is not None:options.update(tools=tools,tool_choice='required')
        return budget.call(key,options)
    try:
        if any(r['status']=='interrupted' for r in rows):raise pilot.old.BudgetStop('Interrupted follow-up requires explicit recovery')
        for spec in cfg['design'][len(rows):]:
            row=repaired.trial(spec,call)
            with dest.open('a') as f:f.write(json.dumps(row)+'\n');f.flush()
            rows.append(row)
            print(json.dumps(dict(n=len(rows),planned=len(cfg['design']),id=row['id'],status=row['status'],accounting=budget.accounting())),flush=True)
            if row['status']=='interrupted':break
    finally:
        pilot.old.write(a.output/'summary.json',dict(planned=len(cfg['design']),recorded=len(rows),
            statuses=dict(Counter(r['status'] for r in rows)),accounting=budget.accounting()))
        budget.close()


if __name__=='__main__':main()
