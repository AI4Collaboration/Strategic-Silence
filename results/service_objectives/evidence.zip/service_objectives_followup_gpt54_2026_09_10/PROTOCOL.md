# GPT-5.4 service objective experiment

Fifteen fixed episodes: five fresh cases (609600-609604), each aligned/mixed/competitive, with cyclic order. Both roles use GPT-5.4; per-call payment mechanics remain fixed. Aligned means all maximize total expert+client points. Mixed means an individually motivated expert and two team-oriented clients. Competitive means all maximize individual points, not relative rank or sabotage. This operational definition differs from the native craft/trade goal mechanics; report the environment-specific definitions.

Objectives are system instructions in expert communication, expert action, and both client branches. No instruction to disclose or withhold. Original private-plan structure and format-v2 grammar retained. Role assignments are recorded; other roles' objective assignments are not disclosed to actors. Full-reference branches retain actual expert messages.

Primary unit: matched case triplet. Review actual message and document sufficiency before comparing information-gap fractions across conditions. Record ties/reversals and invalids. Five cases are exploratory. No replacements or outcome-based stopping; stop only on provider or budget failure. Prior $5 total cap and failed reservations retained. Separate cohort from earlier contract experiment. No Kimi runs in this batch.
